<?php
echo 'Recibi '.$_GET['var'];